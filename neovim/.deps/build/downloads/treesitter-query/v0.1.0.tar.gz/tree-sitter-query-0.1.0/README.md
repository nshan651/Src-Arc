# tree-sitter-query

A tree-sitter parser for tree-sitter query files (scheme-like).
